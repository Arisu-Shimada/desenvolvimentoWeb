<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>form</title>
</head>
<body>
    <form action="processa.php" method="POST">
        <input type="text" name="idade">
        <input type="submit" value="Enviar">
    </form>
</body>
</html>